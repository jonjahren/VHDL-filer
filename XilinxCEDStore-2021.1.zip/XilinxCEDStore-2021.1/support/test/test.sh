vivado -mode tcl -source ./test.tcl -nolog -nojournal
